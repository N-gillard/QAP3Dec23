const express = require('express');
const router = express.Router();
const { getAllUsers, getUser, createUser, updateUser, deleteUser } = require('../dal/db');

router.get('/', async (req, res) => {
  const users = await getAllUsers();
  res.render('index', { users });
});

router.get('/user/:id', async (req, res) => {
  const user = await getUser(req.params.id);
  res.json(user);
});

router.post('/user', async (req, res) => {
  const newUser = await createUser(req.body);
  res.json(newUser);
});

router.put('/user/:id', async (req, res) => {
  const updatedUser = await updateUser(req.params.id, req.body);
  res.json(updatedUser);
});

router.delete('/user/:id', async (req, res) => {
  const deletedUser = await deleteUser(req.params.id);
  res.json(deletedUser);
});

module.exports = router;

