const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Step1',
  password: '',
  port: 5432,
});

const queriesPath = path.join(__dirname, '../../sql/queries.sql');
const queries = fs.readFileSync(queriesPath, 'utf-8').split(';').filter(Boolean);

const executeQuery = async (query, values = []) => {
  const client = await pool.connect();
  try {
    const result = await client.query(query, values);
    return result.rows;
  } finally {
    client.release();
  }
};

const getAllUsers = async () => {
  const query = queries[0];
  return executeQuery(query);
};

const getUser = async (userId) => {
  const query = queries[1];
  return executeQuery(query, [userId]);
};

const createUser = async (user) => {
  const query = queries[2];
  const values = [user.username, user.email, user.role_id, user.department_id];
  return executeQuery(query, values);
};

const updateUser = async (userId, user) => {
  const query = queries[3];
  const values = [user.username, user.email, userId];
  return executeQuery(query, values);
};

const deleteUser = async (userId) => {
  const query = queries[4];
  return executeQuery(query, [userId]);
};

module.exports = {
  getAllUsers,
  getUser,
  createUser,
  updateUser,
  deleteUser,
};
