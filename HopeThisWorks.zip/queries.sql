
SELECT * FROM users WHERE user_id = $1;

INSERT INTO users (username, email, role_id, department_id) VALUES ($1, $2, $3, $4) RETURNING *;

UPDATE users SET username = $1, email = $2 WHERE user_id = $3 RETURNING *;

DELETE FROM users WHERE user_id = $1 RETURNING *;
